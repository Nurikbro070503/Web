<!<!doctype html>
<html>
    <head>
        <title>Title</title>
        <meta http-equiv="Content-Type" content="text/html"; charset="windows-1251"/>
    </head>
    <h1>страница не найдена.</h1>
</html>