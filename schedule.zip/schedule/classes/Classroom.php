<?php
abstract class Classroom extends Table{
    abstract function validate(){
        return false;
    }
            public $classroom_id  = 0;
    public $name  = ''; 
    public $active  = 1;  
}