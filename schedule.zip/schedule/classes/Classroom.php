<?php
abstract class Classroom extends Table{
abstract function validate();
}
