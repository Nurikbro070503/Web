<?php
abstract class ClassroomMap extends BaseMap{
    function arrClassrooms(){
        $res = $this->db->query("SELECT classroom_id AS id, name
AS value FROM classroom WHERE active=1");
return $res->fetchAll(PDO::FETCH_ASSOC);
    }
}