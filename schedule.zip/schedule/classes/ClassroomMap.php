<?php
abstract class ClassroomMap extends BaseMap{} 