<?php
abstract class Config{
const HOST = 'localhost';
const DB_NAME = 'schedule';
const DB_USER = 'root';
const DB_PASSWORD = '';
}