<?php
abstract class Gruppa extends Table{
abstract function validate(){
    if (!empty($this->name) &&
!empty($this->special_id)&&
!empty($this->date_begin)&&
!empty($this->date_end)) {
return true;
}
return false;
}
}
