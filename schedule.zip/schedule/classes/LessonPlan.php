<?php
abstract class LessonPlan extends Table{
abstract function validate();
}
