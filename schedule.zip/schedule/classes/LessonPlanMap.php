<?php
abstract class LessonPlanMap extends BaseMap{} 