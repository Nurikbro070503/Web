<?php
abstract class Otdel extends Table{
abstract function validate();
}
