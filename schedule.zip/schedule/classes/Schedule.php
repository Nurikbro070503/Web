<?php
abstract class Schedule extends Table{
abstract function validate();
}

