<?php
abstract class ScheduleMap extends BaseMap{}