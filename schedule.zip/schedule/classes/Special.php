<?php
abstract class Special extends Table{
abstract function validate(); 
public $special_id = 0;
public $name = '';
public $otdel_id = 0;
}
