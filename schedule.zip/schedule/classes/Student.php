<?php
abstract class Student extends Table{
abstract function validate(); 
}
