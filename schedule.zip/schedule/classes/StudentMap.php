<?php 
abstract class StudentMap extends BaseMap{}