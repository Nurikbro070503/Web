<?php
abstract class Subject extends Table{
abstract function validate();
}
