<?php 
abstract class SubjectMap extends BaseMap{} 
