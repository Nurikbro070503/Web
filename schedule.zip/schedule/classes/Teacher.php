<?php
abstract class Teacher extends Table{
abstract function validate(){
    if (!empty($this->otdel_id)) {
return true;
}
return false;
}
}